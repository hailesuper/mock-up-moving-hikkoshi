import React from "react";
import {Fragment} from "react";
import RegisterForm from "../../components/forms/register.component";

const ServiceRegister = () => {
    return (
        <Fragment>
            <RegisterForm/>
        </Fragment>
    )
}

export default ServiceRegister;