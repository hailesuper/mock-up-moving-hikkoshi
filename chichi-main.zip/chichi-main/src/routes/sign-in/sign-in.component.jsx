import React from "react";
import {Fragment} from "react";
import SignInForm from "../../components/forms/sign-in.component";

const SignIn = () => {
    return (
        <Fragment>
            <SignInForm/>
        </Fragment>
    )
}

export default SignIn;